import { EnvironmentalData, EnvironmentalRiskAnalysis } from '../types';

// 환경 정보 기반 flare 위험도 산출
export function analyzeEnvironmentalRisk(
  environmentalData: EnvironmentalData[]
): EnvironmentalRiskAnalysis {
  if (!environmentalData || environmentalData.length === 0) {
    return {
      riskScore: 0,
      riskLevel: 'low',
      factors: {
        temperature: false,
        humidity: false,
        pressure: false,
        weatherIndex: false
      },
      message: '환경 데이터가 없습니다.',
      recommendations: ['환경 데이터를 확인해주세요.']
    };
  }

  // 최근 데이터 분석 (최근 3일)
  const recentData = environmentalData.slice(-3);
  const avgTemp = recentData.reduce((sum, d) => sum + d.temperature, 0) / recentData.length;
  const avgHumidity = recentData.reduce((sum, d) => sum + d.humidity, 0) / recentData.length;
  const avgWeatherIndex = recentData.reduce((sum, d) => sum + d.weatherIndex, 0) / recentData.length;

  let riskScore = 0;
  const factors = {
    temperature: false,
    humidity: false,
    pressure: false,
    weatherIndex: false
  };
  const riskFactors: string[] = [];

  // 기온 분석 (극단적인 온도가 문제)
  if (avgTemp < 5 || avgTemp > 30) {
    riskScore += 20;
    factors.temperature = true;
    riskFactors.push(`기온 ${avgTemp.toFixed(1)}°C (권장: 15-25°C)`);
  } else if (avgTemp < 10 || avgTemp > 28) {
    riskScore += 10;
    factors.temperature = true;
    riskFactors.push(`기온 ${avgTemp.toFixed(1)}°C`);
  }

  // 습도 분석 (너무 건조하거나 습함)
  if (avgHumidity < 30 || avgHumidity > 80) {
    riskScore += 15;
    factors.humidity = true;
    riskFactors.push(`습도 ${avgHumidity.toFixed(1)}% (권장: 40-60%)`);
  } else if (avgHumidity < 35 || avgHumidity > 75) {
    riskScore += 8;
    factors.humidity = true;
    riskFactors.push(`습도 ${avgHumidity.toFixed(1)}%`);
  }

  // 기압 분석 (급격한 변화가 문제)
  if (recentData.length >= 2) {
    const pressureChange = Math.abs(recentData[recentData.length - 1].pressure - recentData[0].pressure);
    if (pressureChange > 10) {
      riskScore += 15;
      factors.pressure = true;
      riskFactors.push(`기압 급격한 변화 (${pressureChange.toFixed(1)}hPa)`);
    } else if (pressureChange > 5) {
      riskScore += 8;
      factors.pressure = true;
      riskFactors.push(`기압 변화 (${pressureChange.toFixed(1)}hPa)`);
    }
  }

  // 생활기상지수 분석
  if (avgWeatherIndex < 40) {
    riskScore += 20;
    factors.weatherIndex = true;
    riskFactors.push(`생활기상지수 낮음 (${avgWeatherIndex.toFixed(1)})`);
  } else if (avgWeatherIndex < 50) {
    riskScore += 10;
    factors.weatherIndex = true;
    riskFactors.push(`생활기상지수 보통 (${avgWeatherIndex.toFixed(1)})`);
  }

  // 위험 수준 결정
  let riskLevel: 'low' | 'medium' | 'high' | 'critical';
  
  if (riskScore >= 50) {
    riskLevel = 'critical';
  } else if (riskScore >= 30) {
    riskLevel = 'high';
  } else if (riskScore >= 15) {
    riskLevel = 'medium';
  } else {
    riskLevel = 'low';
  }

  // 메시지 생성
  let message = '';
  if (riskLevel === 'critical' || riskLevel === 'high') {
    message = `⚠️ 환경 요인으로 인한 Flare 위험이 ${riskLevel === 'critical' ? '매우 높습니다' : '높습니다'}!`;
    if (riskFactors.length > 0) {
      message += `\n${riskFactors.join(', ')}`;
    }
  } else if (riskLevel === 'medium') {
    message = `⚠️ 환경 요인으로 인한 Flare 위험이 있습니다.`;
    if (riskFactors.length > 0) {
      message += `\n${riskFactors.join(', ')}`;
    }
  } else {
    message = `✅ 현재 환경 조건이 양호합니다.`;
  }

  // 권장 사항 생성
  const recommendations: string[] = [];
  
  if (factors.temperature) {
    if (avgTemp < 10) {
      recommendations.push('실내 온도 유지, 따뜻한 옷 착용');
    } else if (avgTemp > 28) {
      recommendations.push('시원한 곳에서 휴식, 충분한 수분 섭취');
    }
  }
  
  if (factors.humidity) {
    if (avgHumidity < 35) {
      recommendations.push('가습기 사용, 충분한 수분 섭취');
    } else if (avgHumidity > 75) {
      recommendations.push('제습기 사용, 통풍 유지');
    }
  }
  
  if (factors.pressure) {
    recommendations.push('기압 변화 시 휴식, 무리한 활동 자제');
  }
  
  if (factors.weatherIndex) {
    recommendations.push('외출 시 주의, 실내 활동 권장');
  }
  
  if (recommendations.length === 0) {
    recommendations.push('현재 환경 조건을 유지하세요');
  }

  return {
    riskScore: Math.min(100, riskScore),
    riskLevel,
    factors,
    message,
    recommendations
  };
}

// 위경도를 기상청 격자 좌표로 변환
function convertLatLonToGrid(lat: number, lon: number): { nx: number; ny: number } {
  const RE = 6371.00877; // 지구 반경(km)
  const GRID = 5.0; // 격자 간격(km)
  const SLAT1 = 30.0; // 투영 위도1(degree)
  const SLAT2 = 60.0; // 투영 위도2(degree)
  const OLON = 126.0; // 기준점 경도(degree)
  const OLAT = 38.0; // 기준점 위도(degree)
  const XO = 43; // 기준점 X좌표(GRID)
  const YO = 136; // 기준점 Y좌표(GRID)

  const DEGRAD = Math.PI / 180.0;

  const re = RE / GRID;
  const slat1 = SLAT1 * DEGRAD;
  const slat2 = SLAT2 * DEGRAD;
  const olon = OLON * DEGRAD;
  const olat = OLAT * DEGRAD;

  let sn = Math.tan(Math.PI * 0.25 + slat2 * 0.5) / Math.tan(Math.PI * 0.25 + slat1 * 0.5);
  sn = Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(sn);
  let sf = Math.tan(Math.PI * 0.25 + slat1 * 0.5);
  sf = Math.pow(sf, sn) * Math.cos(slat1) / sn;
  let ro = Math.tan(Math.PI * 0.25 + olat * 0.5);
  ro = re * sf / Math.pow(ro, sn);

  let ra = Math.tan(Math.PI * 0.25 + (lat) * DEGRAD * 0.5);
  ra = re * sf / Math.pow(ra, sn);
  let theta = lon * DEGRAD - olon;
  if (theta > Math.PI) theta -= 2.0 * Math.PI;
  if (theta < -Math.PI) theta += 2.0 * Math.PI;
  theta *= sn;

  const nx = Math.floor(ra * Math.sin(theta) + XO + 0.5);
  const ny = Math.floor(ro - ra * Math.cos(theta) + YO + 0.5);

  return { nx, ny };
}

// 현재 시간 기준으로 기상청 API 요청 시간 계산
function getBaseDateTime(isUltraSrt: boolean = false): { baseDate: string; baseTime: string } {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hour = now.getHours();
  const minute = now.getMinutes();
  
  if (isUltraSrt) {
    // 초단기실황: 매 시간 정각에 발표 (현재 시간의 정시 사용)
    // 예: 14:30 -> 14:00, 14:00 -> 14:00
    // 단, 현재 시간이 정각이면 이전 시간 사용 (데이터 준비 시간 고려)
    let baseHour = hour;
    if (minute === 0 && hour > 0) {
      // 정각이면 이전 시간 데이터 사용
      baseHour = hour - 1;
    } else if (hour === 0 && minute === 0) {
      // 새벽 0시 정각이면 전날 23시 사용
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      return {
        baseDate: `${yesterday.getFullYear()}${String(yesterday.getMonth() + 1).padStart(2, '0')}${String(yesterday.getDate()).padStart(2, '0')}`,
        baseTime: '2300'
      };
    }
    
    return {
      baseDate: `${year}${month}${day}`,
      baseTime: String(baseHour).padStart(2, '0') + '00'
    };
  } else {
    // 단기예보: 특정 시간에만 제공 (0200, 0500, 0800, 1100, 1400, 1700, 2000, 2300)
    if (hour < 2) {
      // 새벽 시간대는 전날 23시 데이터 사용
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      return {
        baseDate: `${yesterday.getFullYear()}${String(yesterday.getMonth() + 1).padStart(2, '0')}${String(yesterday.getDate()).padStart(2, '0')}`,
        baseTime: '2300'
      };
    }
    
    // 정시 데이터 사용 (02시, 05시, 08시, 11시, 14시, 17시, 20시, 23시)
    const validHours = [2, 5, 8, 11, 14, 17, 20, 23];
    let baseTimeHour = validHours[0];
    for (let i = validHours.length - 1; i >= 0; i--) {
      if (hour >= validHours[i]) {
        baseTimeHour = validHours[i];
        break;
      }
    }
    
    return {
      baseDate: `${year}${month}${day}`,
      baseTime: String(baseTimeHour).padStart(2, '0') + '00'
    };
  }
}

// OpenWeatherMap API로 실시간 데이터 가져오기 (무료 API)
async function fetchFromOpenWeatherMap(lat: number, lon: number): Promise<(EnvironmentalData & { _isRealTime: true }) | null> {
  try {
    const apiKey = import.meta.env.VITE_WEATHER_API_KEY;
    
    // 상세한 환경 변수 디버깅
    console.log('🔍 API 키 확인 (상세):', {
      hasKey: !!apiKey,
      keyType: typeof apiKey,
      keyValue: apiKey,
      keyLength: apiKey?.length || 0,
      keyPreview: apiKey ? `${apiKey.substring(0, 10)}...${apiKey.substring(apiKey.length - 5)}` : '없음',
      allEnvKeys: Object.keys(import.meta.env).filter(k => k.includes('WEATHER') || k.includes('KMA')),
      mode: import.meta.env.MODE,
      dev: import.meta.env.DEV,
      prod: import.meta.env.PROD
    });
    
    if (!apiKey || apiKey === 'demo_key' || apiKey === 'your_api_key') {
      console.warn('❌ OpenWeatherMap API 키가 설정되지 않았습니다.');
      console.warn('💡 .env 파일에 VITE_WEATHER_API_KEY를 추가하고 서버를 재시작하세요.');
      return null;
    }
    
    console.log('🌐 OpenWeatherMap API 호출 시도...', { lat, lon, apiKeyLength: apiKey?.length });
    
    // fetch API 사용 (더 간단하고 브라우저 네이티브)
    const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric&lang=kr`;
    console.log('🌐 API URL (키 마스킹):', url.replace(apiKey || '', '***'));
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
      // CORS 문제 방지를 위한 옵션
      mode: 'cors',
      cache: 'no-cache'
    });
    
    console.log('📡 API 응답 상태:', {
      ok: response.ok,
      status: response.status,
      statusText: response.statusText
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      console.error('❌ OpenWeatherMap API 호출 실패:', {
        status: response.status,
        statusText: response.statusText,
        data: errorData,
        url: url.replace(apiKey, '***')
      });
      
      if (response.status === 401 || response.status === 403) {
        console.error('🔑 API 키가 유효하지 않습니다!');
        console.error('💡 OpenWeatherMap에서 API 키를 확인하거나 새로 발급받아주세요.');
        console.error('💡 https://openweathermap.org/api 에서 무료 API 키를 발급받을 수 있습니다.');
        console.error('💡 API 키 활성화까지 몇 분이 걸릴 수 있습니다.');
      } else if (response.status === 429) {
        console.error('⏱️ API 호출 한도 초과. 잠시 후 다시 시도해주세요.');
      }
      return null;
    }
    
    const data = await response.json();
    console.log('OpenWeatherMap API 응답:', data);
    
    if (data && data.main) {
      const main = data.main;
      const weatherIndex = calculateWeatherIndex({
        temperature: main.temp,
        humidity: main.humidity,
        pressure: main.pressure
      });
      
      const result = {
        date: new Date().toISOString().split('T')[0],
        temperature: Math.round(main.temp * 10) / 10,
        humidity: main.humidity,
        pressure: Math.round(main.pressure),
        weatherIndex: Math.round(weatherIndex * 10) / 10,
        _isRealTime: true as const  // 실시간 데이터 플래그 명시적으로 설정
      } as EnvironmentalData & { _isRealTime: true };
      
      console.log('✅ 실시간 기상 데이터 수신:', result);
      console.log('✅ _isRealTime 플래그 확인:', result._isRealTime);
      return result;
    }
  } catch (error: any) {
    console.error('❌ OpenWeatherMap API 호출 중 오류:', {
      message: error.message,
      name: error.name
    });
    
    if (error.message.includes('fetch')) {
      console.error('🌐 네트워크 오류 또는 서버 응답 없음. 인터넷 연결을 확인해주세요.');
    }
  }
  
  return null;
}

// 환경 데이터 가져오기
export async function fetchEnvironmentalData(date: string): Promise<EnvironmentalData> {
  try {
    // 대전광역시 유성구 좌표
    const lat = 36.3628;
    const lon = 127.3456;
    
    // 오늘 날짜인 경우에만 실시간 API 호출
    const today = new Date().toISOString().split('T')[0];
    const isToday = date === today;
    
    // 1순위: OpenWeatherMap API 시도 (오늘 날짜일 때만)
    if (isToday) {
      console.log('🔄 오늘 날짜 데이터 요청 - OpenWeatherMap API 호출 시도', { date, today });
      const owmData = await fetchFromOpenWeatherMap(lat, lon);
      if (owmData) {
        console.log('✅ OpenWeatherMap에서 실시간 데이터 수신 성공:', owmData);
        // _isRealTime 플래그가 이미 설정되어 있으므로 그대로 반환
        console.log('✅ 실시간 데이터 플래그 확인:', (owmData as any)._isRealTime);
        return owmData;
      } else {
        console.warn('⚠️ OpenWeatherMap API 호출 실패 또는 데이터 없음, 기상청 API 또는 예시 데이터로 폴백');
        console.warn('⚠️ API 키를 확인하고 브라우저 콘솔의 에러 메시지를 확인하세요.');
      }
    } else {
      console.log(`ℹ️ 과거 날짜 데이터 요청 (${date}) - API 호출 생략, 예시 데이터 사용`);
    }
    
    // 2순위: 기상청 API 시도
    const apiKey = import.meta.env.VITE_KMA_API_KEY;
    
    if (apiKey) {
      const grid = convertLatLonToGrid(lat, lon);
      
      // 기상청 초단기실황 조회 API
      // https://www.data.go.kr/iim/api/selectAPIAcountView.do
      const axios = (await import('axios')).default;
      
      try {
        // 초단기실황 조회 (현재 날씨) - 매 시간 제공
        const { baseDate: ultraBaseDate, baseTime: ultraBaseTime } = getBaseDateTime(true);
        const ultraSrtUrl = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst';
        const ultraSrtParams = {
          serviceKey: decodeURIComponent(apiKey),
          pageNo: '1',
          numOfRows: '10',
          dataType: 'JSON',
          base_date: ultraBaseDate,
          base_time: ultraBaseTime,
          nx: grid.nx.toString(),
          ny: grid.ny.toString()
        };
        
        const ultraSrtResponse = await axios.get(ultraSrtUrl, { params: ultraSrtParams });
        
        if (ultraSrtResponse.data?.response?.body?.items?.item) {
          const items = ultraSrtResponse.data.response.body.items.item;
          
          // 데이터 파싱
          let temperature = 20; // 기본값
          let humidity = 50;
          let pressure = 1013;
          
          items.forEach((item: any) => {
            if (item.category === 'T1H') { // 기온
              temperature = parseFloat(item.obsrValue);
            } else if (item.category === 'REH') { // 습도
              humidity = parseFloat(item.obsrValue);
            } else if (item.category === 'PTY') { // 강수형태는 사용하지 않음
              // 강수형태는 별도 처리
            }
          });
          
          // 기압은 단기예보에서 가져오기
          try {
            const { baseDate: fcstBaseDate, baseTime: fcstBaseTime } = getBaseDateTime(false);
            const fcstUrl = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst';
            const fcstParams = {
              serviceKey: decodeURIComponent(apiKey),
              pageNo: '1',
              numOfRows: '100',
              dataType: 'JSON',
              base_date: fcstBaseDate,
              base_time: fcstBaseTime,
              nx: grid.nx.toString(),
              ny: grid.ny.toString()
            };
            
            const fcstResponse = await axios.get(fcstUrl, { params: fcstParams });
            
            if (fcstResponse.data?.response?.body?.items?.item) {
              const fcstItems = fcstResponse.data.response.body.items.item;
              // 현재 시간에 가장 가까운 예보 시간 찾기
              const now = new Date();
              const currentHour = now.getHours();
              const targetFcstTime = String(currentHour).padStart(2, '0') + '00';
              
              const pressureItem = fcstItems.find((item: any) => 
                item.category === 'PRES' && item.fcstTime === targetFcstTime
              );
              if (pressureItem) {
                pressure = parseFloat(pressureItem.fcstValue) / 100; // hPa로 변환
              }
            }
          } catch (fcstError) {
            console.warn('단기예보 조회 실패, 기본값 사용:', fcstError);
          }
          
          // 생활기상지수 계산
          const weatherIndex = calculateWeatherIndex({ temperature, humidity, pressure });
          
          return {
            date,
            temperature: Math.round(temperature * 10) / 10,
            humidity: Math.round(humidity * 10) / 10,
            pressure: Math.round(pressure * 10) / 10,
            weatherIndex: Math.round(weatherIndex * 10) / 10
          };
        }
      } catch (apiError: any) {
        console.error('기상청 API 호출 실패:', apiError.response?.data || apiError.message);
        // API 실패 시 예시 데이터로 폴백
      }
    }
    
    // 예시 데이터 생성 (API가 없거나 실패 시)
    // ⚠️ 주의: 이는 실제 기상 데이터가 아닌 예시 값입니다
    const apiKeyCheck = import.meta.env.VITE_WEATHER_API_KEY || import.meta.env.VITE_KMA_API_KEY;
    console.warn('⚠️ 예시 데이터 생성 중:', {
      date,
      hasWeatherApiKey: !!import.meta.env.VITE_WEATHER_API_KEY,
      hasKmaApiKey: !!import.meta.env.VITE_KMA_API_KEY,
      apiKeyPreview: apiKeyCheck ? `${apiKeyCheck.substring(0, 10)}...` : '없음'
    });
    
    const month = new Date(date).getMonth();
    
    // 대전 유성구 계절별 평균 기온 (실제 평균값 기반)
    let baseTemp = 12; // 봄/가을 기본값 (3-5월, 9-11월)
    let baseHumidity = 55;
    let basePressure = 1015;
    
    if (month >= 5 && month <= 8) { // 여름 (6-8월)
      baseTemp = 26;
      baseHumidity = 75;
      basePressure = 1005;
    } else if (month >= 11 || month <= 2) { // 겨울 (12-2월)
      baseTemp = 2;
      baseHumidity = 50;
      basePressure = 1020;
    } else if (month >= 2 && month <= 4) { // 봄 (3-5월)
      baseTemp = 15;
      baseHumidity = 60;
      basePressure = 1013;
    } else if (month >= 8 && month <= 10) { // 가을 (9-11월)
      baseTemp = 18;
      baseHumidity = 65;
      basePressure = 1015;
    }
    
    // 일일 변동 추가 (실제 날씨와 유사하게, 랜덤 대신 날짜 기반)
    // 같은 날짜면 같은 값이 나오도록 (시드 사용)
    const dateSeed = parseInt(date.replace(/-/g, '')) % 100;
    const dayVariation = (dateSeed % 20 - 10) * 0.3; // ±3도 범위
    const temperature = baseTemp + dayVariation;
    const humidity = baseHumidity + (dateSeed % 30 - 15) * 0.5; // ±7.5% 범위
    const pressure = basePressure + (dateSeed % 20 - 10) * 0.2; // ±2hPa 범위
    
    // 생활기상지수 계산 (0-100)
    let weatherIndex = 70;
    if (temperature < 5 || temperature > 30) weatherIndex -= 20;
    if (humidity < 30 || humidity > 80) weatherIndex -= 15;
    if (pressure < 1000 || pressure > 1025) weatherIndex -= 10;
    weatherIndex = Math.max(0, Math.min(100, weatherIndex));
    
    return {
      date,
      temperature: Math.round(temperature * 10) / 10,
      humidity: Math.round(humidity * 10) / 10,
      pressure: Math.round(pressure * 10) / 10,
      weatherIndex: Math.round(weatherIndex * 10) / 10
    };
  } catch (error) {
    console.error('환경 데이터 가져오기 실패:', error);
    // 기본값 반환
    return {
      date,
      temperature: 20,
      humidity: 50,
      pressure: 1013,
      weatherIndex: 70
    };
  }
}

// 생활기상지수 계산 함수 (API 데이터 기반)
function calculateWeatherIndex(weatherData: { temperature: number; humidity: number; pressure: number }): number {
  let index = 70; // 기본값
  
  // 기온 점수 (15-25°C가 최적)
  if (weatherData.temperature >= 15 && weatherData.temperature <= 25) {
    index += 10;
  } else if (weatherData.temperature >= 10 && weatherData.temperature < 15) {
    index += 5;
  } else if (weatherData.temperature > 25 && weatherData.temperature <= 30) {
    index += 5;
  } else if (weatherData.temperature < 5 || weatherData.temperature > 30) {
    index -= 20;
  } else {
    index -= 10;
  }
  
  // 습도 점수 (40-60%가 최적)
  if (weatherData.humidity >= 40 && weatherData.humidity <= 60) {
    index += 10;
  } else if (weatherData.humidity >= 30 && weatherData.humidity < 40) {
    index += 5;
  } else if (weatherData.humidity > 60 && weatherData.humidity <= 70) {
    index += 5;
  } else if (weatherData.humidity < 30 || weatherData.humidity > 80) {
    index -= 15;
  } else {
    index -= 10;
  }
  
  // 기압 점수 (1000-1025hPa가 정상)
  if (weatherData.pressure >= 1000 && weatherData.pressure <= 1025) {
    index += 10;
  } else if (weatherData.pressure < 1000 || weatherData.pressure > 1025) {
    index -= 10;
  }
  
  return Math.max(0, Math.min(100, index));
}

